import tkinter as tk
from tkinter import messagebox
import json
import os

class EncyclopediaApp:
    def __init__(self, root):
        self.root = root
        self.current_theme = "light"
        self.setup_themes()
        self.setup_window()
        self.setup_ui()
        self.show_alphabet()

    def setup_themes(self):
        self.themes = {
            "light": {
                "text": "#1A202C",
                "bg": "#EDF2F7",
                "button": "#718096",
                "hover": "#4A5568"
            },
            "dark": {
                "text": "#EDF2F7",
                "bg": "#1A202C",
                "button": "#4FD1C5",
                "hover": "#38B2AC"
            }
        }

    def setup_window(self):
        self.root.title("Энциклопедия «Хочу все знать 2025»")
        self.root.geometry("800x600")
        self.root.minsize(600, 400)
        self.apply_theme()

    def setup_ui(self):
        control_frame = tk.Frame(self.root, bg=self.themes[self.current_theme]["bg"])
        control_frame.pack(fill="x", padx=10, pady=5)
        
        self.theme_button = tk.Button(
            control_frame, 
            text="🌙" if self.current_theme == "light" else "☀️",
            command=self.toggle_theme,
            font=("Helvetica", 12), 
            fg="white", 
            bg=self.themes[self.current_theme]["button"],
            relief="flat", 
            bd=0, 
            padx=10
        )
        self.theme_button.pack(side="right", padx=20, pady=5)

        tk.Label(
            self.root, 
            text="Выберите букву:",
            font=("Helvetica", 24, "bold"),
            fg=self.themes[self.current_theme]["text"], 
            bg=self.themes[self.current_theme]["bg"]
        ).pack(pady=20)
        
        self.content_frame = tk.Frame(self.root, bg=self.themes[self.current_theme]["bg"])
        self.content_frame.pack(fill="both", expand=True, padx=20, pady=10)

    def toggle_theme(self):
        self.current_theme = "dark" if self.current_theme == "light" else "light"
        self.apply_theme()
        self.theme_button.config(
            text="🌙" if self.current_theme == "light" else "☀️",
            bg=self.themes[self.current_theme]["button"]
        )

    def apply_theme(self):
        theme = self.themes[self.current_theme]
        self.root.configure(bg=theme["bg"])
        
        for widget in self.root.winfo_children():
            if isinstance(widget, tk.Frame):
                widget.configure(bg=theme["bg"])
            elif isinstance(widget, tk.Label):
                if "text" in widget.keys():
                    widget.configure(fg=theme["text"], bg=theme["bg"])
        
        if hasattr(self, 'content_frame'):
            for widget in self.content_frame.winfo_children():
                self.update_widget_theme(widget)

    def update_widget_theme(self, widget):
        theme = self.themes[self.current_theme]
        if isinstance(widget, tk.Frame):
            widget.configure(bg=theme["bg"])
            for child in widget.winfo_children():
                self.update_widget_theme(child)
        elif isinstance(widget, (tk.Label, tk.Button)):
            widget.configure(
                fg="white" if isinstance(widget, tk.Button) else theme["text"],
                bg=theme["button"] if isinstance(widget, tk.Button) else theme["bg"],
                activebackground=theme["hover"],
                activeforeground="white"
            )
        elif isinstance(widget, (tk.Canvas, tk.Text)):
            widget.configure(
                bg=theme["bg"],
                fg=theme["text"],
                highlightthickness=0
            )
        elif isinstance(widget, tk.Scrollbar):
            widget.configure(bg=theme["button"])

    def load_data(self, letter):
        try:
            file_name = f"data_{letter.lower()}.json"
            file_path = os.path.join(os.path.dirname(__file__), file_name)
            
            if not os.path.exists(file_path):
                return {"Информация": f"Файл для буквы {letter} не найден"}
            
            with open(file_path, "r", encoding="utf-8-sig") as file:
                content = file.read().strip()
                
                if not content:
                    return {"Ошибка": "Файл пустой"}
                
                if content.startswith('\ufeff'):
                    content = content[1:]
                
                data = json.loads(content)
                
                if not isinstance(data, dict):
                    return {"Ошибка": "Неверный формат данных"}
                
                return data
                
        except Exception as e:
            return {"Ошибка": f"Ошибка загрузки: {str(e)}"}

    def show_words(self, letter):
        data = self.load_data(letter)
        
        for widget in self.content_frame.winfo_children():
            widget.destroy()

        tk.Button(
            self.content_frame, 
            text="← Назад к буквам",
            command=self.show_alphabet,
            font=("Helvetica", 12), 
            fg="white", 
            bg=self.themes[self.current_theme]["button"],
            relief="flat", 
            bd=0, 
            padx=20, 
            pady=5,
            activebackground=self.themes[self.current_theme]["hover"]
        ).pack(pady=10)

        canvas = tk.Canvas(
            self.content_frame, 
            bg=self.themes[self.current_theme]["bg"], 
            highlightthickness=0
        )
        scrollbar = tk.Scrollbar(
            self.content_frame, 
            orient="vertical", 
            command=canvas.yview,
            bg=self.themes[self.current_theme]["button"]
        )
        canvas.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        
        words_frame = tk.Frame(canvas, bg=self.themes[self.current_theme]["bg"])
        canvas.create_window((0, 0), window=words_frame, anchor="nw")

        if "Ошибка" in data or "Информация" in data:
            message = data.get("Ошибка") or data.get("Информация")
            tk.Label(
                words_frame, 
                text=message,
                font=("Helvetica", 14), 
                fg=self.themes[self.current_theme]["text"], 
                bg=self.themes[self.current_theme]["bg"]
            ).pack(pady=20)
        else:
            for word, meaning in data.items():
                tk.Button(
                    words_frame, 
                    text=word, 
                    width=25,
                    command=lambda w=word, m=meaning: self.show_meaning(w, m),
                    font=("Helvetica", 12), 
                    fg="white", 
                    bg=self.themes[self.current_theme]["button"],
                    relief="flat", 
                    padx=15, 
                    pady=7,
                    activebackground=self.themes[self.current_theme]["hover"]
                ).pack(pady=5, padx=10)
        
        words_frame.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))

    def show_alphabet(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
            
        center_frame = tk.Frame(self.content_frame, bg=self.themes[self.current_theme]["bg"])
        center_frame.pack(expand=True)
        
        for i, letter in enumerate("АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"):
            tk.Button(
                center_frame, 
                text=letter, 
                width=4,
                command=lambda l=letter: self.show_words(l),
                font=("Helvetica", 14), 
                fg="white", 
                bg=self.themes[self.current_theme]["button"],
                relief="flat", 
                padx=15, 
                pady=10,
                activebackground=self.themes[self.current_theme]["hover"]
            ).grid(row=i//6, column=i%6, padx=5, pady=5)

    def show_meaning(self, word, meaning):
        win = tk.Toplevel(self.root)
        win.title(word)
        win.geometry("500x300")
        win.configure(bg=self.themes[self.current_theme]["bg"])
        
        tk.Label(
            win, 
            text=word, 
            font=("Helvetica", 16, "bold"),
            fg=self.themes[self.current_theme]["text"], 
            bg=self.themes[self.current_theme]["bg"]
        ).pack(pady=10)
        
        text_frame = tk.Frame(win, bg=self.themes[self.current_theme]["bg"])
        text_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        text = tk.Text(
            text_frame, 
            wrap="word", 
            font=("Helvetica", 12),
            fg=self.themes[self.current_theme]["text"], 
            bg=self.themes[self.current_theme]["bg"],
            padx=10, 
            pady=10, 
            highlightthickness=0
        )
        text.insert("1.0", meaning)
        text.config(state="disabled")
        
        scrollbar = tk.Scrollbar(
            text_frame, 
            command=text.yview,
            bg=self.themes[self.current_theme]["button"]
        )
        scrollbar.pack(side="right", fill="y")
        text.config(yscrollcommand=scrollbar.set)
        text.pack(side="left", fill="both", expand=True)
        
        tk.Button(
            win, 
            text="Закрыть", 
            command=win.destroy,
            font=("Helvetica", 10), 
            fg="white", 
            bg=self.themes[self.current_theme]["button"],
            relief="flat", 
            padx=15, 
            pady=5,
            activebackground=self.themes[self.current_theme]["hover"]
        ).pack(pady=10)

if __name__ == "__main__":
    root = tk.Tk()
    app = EncyclopediaApp(root)
    root.mainloop()